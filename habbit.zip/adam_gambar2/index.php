<?php
include "koneksi.php";
include "session.php";
$sql = "SELECT * FROM instagram ORDER BY no desc";
$query = mysqli_query($koneksi, $sql);

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Habbit Homepage</title>
    <link rel="shortcut icon" href="images/asset/icon.png" type="image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <style>
        .zoom {
            overflow: hidden;
            margin: 0 auto;
        }

        .zoom img {
            width: 100%;
            transition: 0.5s all ease-in-out;
        }

        .zoom:hover img {
            transform: scale(1.5);
        }
    </style>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light sticky-top">
        <div class="container-fluid">
            <img src="images/asset/full icon.png" alt="" height="75">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
        </div>
        <button class="btn btn-primary mx-3" data-bs-toggle="modal" data-bs-target="#exampleModal"><i class="bi bi-plus-lg"></i></button>
        <a href="logout.php"><button class="btn btn-secondary"><i class="bi bi-box-arrow-right"></i></button></a>
    </nav>

    <?php while ($foto = mysqli_fetch_assoc($query)) { ?>
        <center>
            <div class="container py-3 align-center justify-center">
                <div class="card" style="width: 600px;">
                    <div class="zoom">
                        <img src="images/uploads/<?= $foto['foto'] ?>" class="card-img-top" height="400px" width="600px">
                    </div>
                    <div class="card-body">
                        <div class="container">
                            <div class="row">
                                <div class="col">
                                    <i class="bi bi-heart"></i>
                                </div>
                                <div class="col">
                                    <i class="bi bi-chat"></i>
                                </div>
                                <div class="col">
                                    <i class="bi bi-send" type="button" data-bs-toggle="modal" data-bs-target="#modalBagikan"></i>
                                </div>
                            </div>
                        </div>
                        <h5 class="card-title text-start"><?= $foto['location'] ?></h5>
                        <p class="card-text text-start"><?= $foto['caption'] ?></p>
                        <button class="btn btn-success mx-3" data-bs-toggle="modal" data-bs-target="#editModal<?= $foto['no'] ?>"><i class="bi bi-pencil-square"></i></button>

                        <a href="hapus.php?no=<?= $foto['no'] ?>" class="btn btn-danger"><i class="bi bi-trash"></i></a>
                    </div>
                </div>
            </div>
        </center>
        <!-- Modal Edit -->
        <div class="modal fade" id="editModal<?= $foto['no'] ?>" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Form Edit</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form action="proses_edit.php" method="post" enctype="multipart/form-data">
                            <input type="hidden" name="no" value="<?= $foto['no'] ?>">
                            <input type="hidden" name="foto_lama" value="<?= $foto['foto'] ?>">
                            <div class="mb-3">
                                <label class="form-label">Image</label><br>
                                <div class="mb-2">
                                    <?php if ($foto['foto'] == null) { ?>
                                        <img id="blah" src="images/asset/default.png" alt="your image" width="100" />
                                    <?php } else { ?>
                                        <img id="blah" src="images/uploads/<?= $foto['foto'] ?>" alt="your image" width="100" />
                                    <?php } ?>
                                </div>
                                <input type="file" name="foto" class="form-control form-control-lg bg-light fs-6" id="imgInp" value="<?= $foto['foto'] ?>">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Caption</label><br>
                                <input type="text" class="form-control form-control-lg bg-light fs-6" name="caption" autocomplete="off" value="<?= $foto['caption'] ?>">
                            </div>
                            <div class="mb-1">
                                <label class="form-label">Location</label><br>
                                <input type="text" class="form-control form-control-lg bg-light fs-6" name="location" autocomplete="off" value="<?= $foto['location'] ?>">
                            </div>
                            <div class="input-group mb-4 d-flex justify-content-between">

                            </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <input type="submit" class="btn btn-primary" value="Update" name="update">
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- Modal URL Share -->
        <div class="modal fade" id="modalBagikan" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Bagikan URL</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <!-- Input untuk menampilkan URL -->
                        <div class="input-group mb-3">
                            <input type="text" class="form-control" id="urlToShare" readonly>
                            <button class="btn btn-outline-secondary" type="button" id="copyButton">
                                <i class="bi bi-clipboard"></i>
                            </button>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                    </div>
                </div>
            </div>
        </div>
    <?php } ?>

    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Form Tambah</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="proses_tambah.php" method="post" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label class="form-label">Image</label><br>
                            <div class="mb-2">
                                <img id="blah" src="images/asset/default.png" alt="your image" width="100" />
                            </div>
                            <input type="file" name="foto" class="form-control form-control-lg bg-light fs-6" id="imgInp" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Caption</label><br>
                            <input type="text" class="form-control form-control-lg bg-light fs-6" name="caption" autocomplete="off">
                        </div>
                        <div class="mb-1">
                            <label class="form-label">Location</label><br>
                            <input type="text" class="form-control form-control-lg bg-light fs-6" name="location" autocomplete="off">
                        </div>
                        <div class="input-group mb-4 d-flex justify-content-between">

                        </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <input type="submit" class="btn btn-primary" value="Save" name="simpan">
                    </form>
                </div>
            </div>
        </div>
    </div>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function(e) {
                    $('#blah').attr('src', e.target.result);
                }

                reader.readAsDataURL(input.files[0]);
            }
        }

        $("#imgInp").change(function() {
            readURL(this);
        });

        // alert 
        $(document).ready(function() {
            // Fungsi untuk menampilkan SweetAlert
            function showSweetAlert(icon, title, text) {
                Swal.fire({
                    icon: icon,
                    title: title,
                    text: text,
                    confirmButtonText: 'Ok'
                }).then(function() {
                    // Hapus parameter dari URL
                    var newUrl = window.location.href
                        .replace('?tambah=sukses', '')
                        .replace('?edit=sukses', '')
                        .replace('?hapus=sukses', '');

                    // Ganti URL tanpa parameter
                    window.history.replaceState({}, document.title, newUrl);
                });;
            }

            // Cek URL untuk menentukan operasi
            var urlParams = new URLSearchParams(window.location.search);
            if (urlParams.has('tambah') && urlParams.get('tambah') === 'sukses') {
                showSweetAlert('success', 'Data berhasil ditambahkan!', 'Data telah disimpan ke dalam database.');
            } else if (urlParams.has('edit') && urlParams.get('edit') === 'sukses') {
                showSweetAlert('info', 'Data berhasil diubah!', 'Perubahan telah disimpan.');
            } else if (urlParams.has('hapus') && urlParams.get('hapus') === 'sukses') {
                showSweetAlert('warning', 'Data berhasil dihapus!', 'Data telah dihapus dari database.');
            }
        });

        // salin clipboard
        $(document).ready(function () {
            // Mendapatkan alamat URL halaman saat ini
            var currentURL = window.location.href;

            // Mengisi nilai input dengan URL halaman
            $('#urlToShare').val(currentURL);

            // Menyalin URL saat mengklik tombol "Salin"
            $('#copyButton').on('click', function () {
                var urlToCopy = document.getElementById('urlToShare');
                urlToCopy.select();
                document.execCommand('copy');
                alert('URL telah disalin ke clipboard.');
            });
        });
    </script>
</body>

</html>