<?php
include "koneksi.php";
require "functions.php";
if (isset($_POST['simpan'])) {

    $caption = $_POST['caption'];
    $location = $_POST["location"];
    $foto = upload(); 
    $sql = "INSERT INTO instagram (foto, caption, location) VALUES ('$foto', '$caption', '$location')";
    var_dump($sql);
    // die;
    $query = mysqli_query($koneksi, $sql);

    if ($query) {
        header("location:index.php?tambah=sukses");
    } else {
        header("location:index.php?tambah=gagal");
    }
} 


?>