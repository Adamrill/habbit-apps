<?php
include "koneksi.php";

$no = $_GET['no'];
$sql = "SELECT * FROM instagram WHERE no = '$no' ";
$query = mysqli_query($koneksi, $sql);
while ($foto = mysqli_fetch_assoc($query)) {
?>

    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
    </head>

    <body>
        <h1>Edit Post</h1>
        <form action="proses_edit.php" method="post" enctype="multipart/form-data">
            <input type="hidden" name="no" value="<?= $foto['no'] ?>">
            <input type="hidden" name="foto_lama" value="<?= $foto['foto'] ?>">
           
            <label for="">Foto</label>
            <input type="file" name="foto" id="" value="<?= $foto['foto'] ?>"><br><br>
            <img src="images/uploads/<?= $foto['foto'] ?>" width="100" alt=""><br>
            <div class="mb-3">
                <label>Caption</label>
                <input type="text" name="caption" class="form-control" value="<?= $foto['caption'] ?>">
            </div>
            <div class="mb-3">
                <label for="">Location</label>
                <input type="text" name="location" id="" autocomplete="off" class="form-control" value="<?= $foto['location'] ?>">
            </div>
            <input type="submit" value="Update" name="update">
        </form>
    </body>

    </html>

<?php } ?>