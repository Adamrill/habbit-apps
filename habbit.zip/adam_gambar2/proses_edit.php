<?php
include "koneksi.php";
require "functions.php";
var_dump($_POST);
var_dump($_FILES);
// die;

if (isset($_POST['update'])) {
    $no = $_POST['no'];
    $caption = $_POST['caption'];
    $location = $_POST["location"];
    $foto_lama = $_POST['foto_lama'];
    $foto_baru = $_FILES['foto']['name'];

    // jika gambarnya sama, pakai foto yang lama
    if( $_FILES['foto']['error'] === 4 ) {
		$foto = $foto_lama;
	} else {
        $sql = "SELECT * FROM instagram WHERE no = '$no' ";
        $query = mysqli_query($koneksi, $sql);
    
        // menghapus foto lama karena nanti akan diganti yang baru
        while($siswa = mysqli_fetch_assoc($query)) {
            $foto = $siswa['foto'];
            unlink('images/uploads/' . $foto);
        }

        // lakukan proses upload gambar baru
		$foto = upload();
	}
    
    $sql2 = "UPDATE instagram SET caption = '$caption', foto = '$foto', location = '$location' WHERE no = '$no' ";
    $query2 = mysqli_query($koneksi, $sql2);

    if ($query2) {
        header("location:index.php?edit=sukses");
    } else {
        header("location:index.php?edit=gagal");
    }
    
}